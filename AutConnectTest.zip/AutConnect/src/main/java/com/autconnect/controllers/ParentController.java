package com.autconnect.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class ParentController {

}
