package com.autconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutConnectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutConnectApplication.class, args);
	}

}
