package com.autconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
